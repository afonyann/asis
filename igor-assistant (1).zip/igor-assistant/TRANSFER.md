# Перенос проекта в новую среду / новый Devin-чат

Этот документ — всё что нужно чтобы продолжить работу над ботом из любого
нового Devin-чата (или своими руками, локально / на сервере).

## Что куда задеплоено (живёт у тебя в Cloudflare)

- **Worker (сам бот)**: `https://igor-assistant.afonyakinzahar.workers.dev`
  - Webhook Telegram: `/webhook`
  - Mini-app: `/app`
  - Cron: `* * * * *` (каждую минуту, для напоминаний и утренних/вечерних сообщений)
- **D1 database**: `igor_assistant_db` — id `092a054b-1d6e-4b86-b457-3e8f4923cdf1`
  (там вся история: пользователи, привычки, задачи, тренировки, еда, цели, напоминания, платежи)
- **Telegram-бот**: создан через `@BotFather`, токен ниже

Worker и D1 продолжают работать независимо от Devin / VM. Их трогать не надо
пока ты не решишь что-то изменить в коде.

## Секреты (НЕ коммитить!)

```
TELEGRAM_BOT_TOKEN=8765260975:AAGCpe9gBnMT5oN_rh4_IGShQ3vFOxsJ5W0
GROQ_API_KEY=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
GEMINI_API_KEY=AIzaSyCQecbJJQXcJG8LEKC9Vk5LLAPeCGSU4sE
CLOUDFLARE_API_TOKEN=cfut_y6incQPQImzJmwCFfBycIY58iV4J4VALfxZJku1fc06244e2
CLOUDFLARE_ACCOUNT_ID=c47bcf660d61ad3f33515c9ae38f1df4
CLOUDFLARE_EMAIL=Afonyakinzahar@gmail.com
TG_OWNER_ID=1209572157
WORKER_BASE_URL=https://igor-assistant.afonyakinzahar.workers.dev
D1_DATABASE_ID=092a054b-1d6e-4b86-b457-3e8f4923cdf1
DEFAULT_TIMEZONE=Europe/Moscow
```

## Восстановление в новой Devin-сессии

1. Распакуй архив: `unzip igor-assistant.zip -d ~/repos/`
2. Положи секреты в файл `~/.assistant_creds` (можно скопировать блок выше)
3. Скажи Devin что-то вроде:

> Это бот-ассистент в Telegram. Исходники в `~/repos/igor-assistant`.
> Деплоится на Cloudflare Workers под аккаунтом `Afonyakinzahar@gmail.com`.
> Секреты в `~/.assistant_creds`. Worker URL —
> `https://igor-assistant.afonyakinzahar.workers.dev`.
> Прочитай `TRANSFER.md` и `README.md` чтобы понять структуру, потом я скажу что делать.

Devin сам прочитает код и контекст подтянется.

## Установка деплой-инструментов (если делаешь сам)

```bash
cd ~/repos/igor-assistant
npm install
# Деплой требует CLOUDFLARE_API_TOKEN и CLOUDFLARE_ACCOUNT_ID:
source ~/.assistant_creds
CLOUDFLARE_API_TOKEN=$CLOUDFLARE_API_TOKEN \
CLOUDFLARE_ACCOUNT_ID=$CLOUDFLARE_ACCOUNT_ID \
  npx wrangler deploy
```

## Установка секретов в Worker (одноразово, уже сделано)

Если нужно их обновить:

```bash
echo -n "$TELEGRAM_BOT_TOKEN" | npx wrangler secret put TELEGRAM_BOT_TOKEN
echo -n "$GROQ_API_KEY"       | npx wrangler secret put GROQ_API_KEY
echo -n "$GEMINI_API_KEY"     | npx wrangler secret put GEMINI_API_KEY
```

Не-секретные переменные (`TG_OWNER_ID`, `DEFAULT_TIMEZONE`, `WORKER_BASE_URL`,
`GEMINI_MODEL`) задаются в `wrangler.jsonc` → `vars` и применяются при `wrangler deploy`.

## Миграции БД

Лежат в `migrations/`. Применяются:

```bash
npx wrangler d1 migrations apply igor_assistant_db --remote
```

Wrangler сам отслеживает применённые миграции в системной таблице
`d1_migrations` внутри той же D1.

## Telegram webhook

Уже выставлен на `https://igor-assistant.afonyakinzahar.workers.dev/webhook`
с `allowed_updates = ["message","edited_message","pre_checkout_query"]`.
Перевыставить:

```bash
curl -s "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/setWebhook" \
  -d "url=https://igor-assistant.afonyakinzahar.workers.dev/webhook" \
  -d 'allowed_updates=["message","edited_message","pre_checkout_query"]'
```

## Структура кода

- `src/index.ts` — entrypoint Worker (роутер + cron)
- `src/bot.ts` — обработка Telegram-апдейтов (команды, диалог, оплата)
- `src/llm.ts` — вызовы LLM (Groq Llama 3.3 → fallback Gemini), tool-loop
- `src/intent.ts` — fast-path парсер (детерминированные команды без LLM)
- `src/tools.ts` — реализация всех LLM-инструментов
- `src/db.ts` — все запросы в D1
- `src/scheduler.ts` — cron (напоминания, утренние/вечерние сообщения)
- `src/groq.ts` — Whisper-large-v3-turbo (транскрипт голосовых)
- `src/telegram.ts` — клиент Telegram Bot API
- `src/time.ts` — парсинг времени, таймзоны
- `src/webapp_api.ts` / `src/webapp_auth.ts` / `src/webapp_html.ts` —
  Telegram Mini App (REST + initData проверка)
- `src/static/app.html` — фронт мини-аппа (один HTML, vanilla JS)
- `migrations/*.sql` — D1 schema migrations

## Как продолжить разработку

1. Внести изменения в `src/`
2. `npx tsc --noEmit` — проверить типы
3. `npx wrangler deploy` — задеплоить
4. Если миграция — `npx wrangler d1 migrations apply igor_assistant_db --remote`

## Где живут пользователи и подписки

- Все юзеры в таблице `users` (id = их telegram id)
- Owner — id `1209572157` (ты), `sub_status = 'owner'`
- Новые юзеры получают `sub_status = 'trial'` на 14 дней автоматически
- `/grant @username` или `/grant <id>` — команды владельца, дают `sub_status = 'granted'`
- Telegram Stars платежи пишутся в таблицу `payments` и продлевают `sub_until`

## Если Cloudflare аккаунт переезжает

1. Создаёшь новый D1: `npx wrangler d1 create igor_assistant_db`
2. Копируешь новый id в `wrangler.jsonc`
3. Применяешь миграции: `npx wrangler d1 migrations apply igor_assistant_db --remote`
4. Экспорт старой БД: `npx wrangler d1 export igor_assistant_db --remote --output dump.sql`
5. Импорт в новую: `npx wrangler d1 execute igor_assistant_db --remote --file dump.sql`

Worker URL изменится на новый поддомен — нужно перевыставить webhook
(`setWebhook` из секции выше) и обновить ссылку на мини-апп если используешь
её отдельно.
